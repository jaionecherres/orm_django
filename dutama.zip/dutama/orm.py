import os
import django
from django.contrib.auth.models import User
from core.models import Periodo, Asignatura, Profesor, Estudiante, Nota, DetalleNota

def probar_orm():
    # Configurar Django
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'gest_aca.settings')
    django.setup()

    # Obtener el usuario 'admin' o crearlo si no existe
    user, created = User.objects.get_or_create(username='admin')

    # Función para crear periodos académicos
    def crear_periodos():
        periodos = [
            Periodo(periodo='2024-2025', user=user),
            Periodo(periodo='2025-2026', user=user),
            Periodo(periodo='2026-2027', user=user),
            Periodo(periodo='2027-2028', user=user),
            Periodo(periodo='2028-2029', user=user),
            Periodo(periodo='2030-2031', user=user),
            Periodo(periodo='2031-2032', user=user),
            Periodo(periodo='2032-2033', user=user),
            Periodo(periodo='2034-2035', user=user),
            Periodo(periodo='2035-2026', user=user),
        ]
        try:
            Periodo.objects.bulk_create(periodos)
            print("Se han insertado 10 registros en la tabla Periodo.")
        except Exception as e:
            print(f"Error al insertar periodos: {e}")

    # Función para crear asignaturas
    def crear_asignaturas():
        asignaturas = [
            Asignatura(descripcion='Matemáticas', user=user),
            Asignatura(descripcion='Ciencias Naturales', user=user),
            Asignatura(descripcion='Historia', user=user),
            Asignatura(descripcion='Lengua y Literatura', user=user),
            Asignatura(descripcion='Educación Física', user=user),
            Asignatura(descripcion='Arte', user=user),
            Asignatura(descripcion='Música', user=user),
            Asignatura(descripcion='Tecnología', user=user),
            Asignatura(descripcion='Informática', user=user),
            Asignatura(descripcion='Ciencias Sociales', user=user),
        ]
        try:
            Asignatura.objects.bulk_create(asignaturas)
            print("Se han insertado 10 registros en la tabla Asignatura.")
        except Exception as e:
            print(f"Error al insertar asignaturas: {e}")

    # Función para crear profesores
    def crear_profesores():
        profesores = [
            Profesor(cedula='0101010101', nombre='Luis', user=user),
            Profesor(cedula='0202020202', nombre='Daniela', user=user),
            Profesor(cedula='0303030303', nombre='Rosa', user=user),
            Profesor(cedula='0404040404', nombre='Jorge', user=user),
            Profesor(cedula='0505050505', nombre='Pedro', user=user),
            Profesor(cedula='0606060606', nombre='Maria', user=user),
            Profesor(cedula='0707070707', nombre='Marlon', user=user),
            Profesor(cedula='0808080808', nombre='Teodoro', user=user),
            Profesor(cedula='0909090909', nombre='Daniel', user=user),
            Profesor(cedula='1010101010', nombre='Isabel', user=user)
        ]
        try:
            Profesor.objects.bulk_create(profesores)
            print("Se han insertado 10 registros en la tabla Profesor.")
        except Exception as e:
            print(f"Error al insertar profesores: {str(e)}")
    def crear_estudiantes():
            # Crear estudiantes
            estudiantes = [
                Estudiante(cedula='1234567890', nombre='Eliane', user=user),
                Estudiante(cedula='2345678901', nombre='Eneritz', user=user),
                Estudiante(cedula='3456789012', nombre='Maitte', user=user),
                Estudiante(cedula='4567890123', nombre='Rodrigo', user=user),
                Estudiante(cedula='5678901234', nombre='Tomas', user=user),
                Estudiante(cedula='6789012345', nombre='León', user=user),
                Estudiante(cedula='7890123456', nombre='Victor', user=user),
                Estudiante(cedula='8901234567', nombre='Esteban', user=user),
                Estudiante(cedula='9012345678', nombre='Ronny', user=user),
                Estudiante(cedula='0123456789', nombre='Camila', user=user),
            ]

            try:
                Estudiante.objects.bulk_create(estudiantes)
                print("Se han insertado 10 registros en la tabla Estudiante.")
            except Exception as e:
                print(f"Error al insertar estudiantes: {e}")

    def crear_notas():
        # Crear notas con .create() y .save()
        periodos = Periodo.objects.all()[:10]
        asignaturas = Asignatura.objects.all()[:10]
        profesores = Profesor.objects.all()[:10]

        for i in range(10):
            nota = Nota.objects.create(
                periodo=periodos[i],
                asignatura=asignaturas[i],
                profesor=profesores[i],
                user=user  # Asignar el usuario 'admin'
            )
            nota.save()

        print("Se han insertado 10 registros en la tabla Nota.")

    def crear_detalles_notas():
        estudiantes = list(Estudiante.objects.all()[:10])  # Asumimos que hay al menos 10 estudiantes
        notas = list(Nota.objects.all()[:10])  # Asumimos que hay al menos 10 notas

        if len(estudiantes) < 10 or len(notas) < 10:
            print("No hay suficientes estudiantes o notas para crear detalles de notas.")
            return

        for i in range(10):
            detalle_nota =  DetalleNota.objects.create(
                estudiante=estudiantes[i],
                nota=notas[i],
                nota1=round(5.0 + (i % 5), 2),
                nota2=round(5.0 + ((i + 1) % 5), 2),
                recuperacion=round(4.0 + (i % 4), 2) if i % 3 == 0 else None,  # Algunos tendrán nota de recuperación
                observacion=f"Observación para estudiante {i + 1}",
                user=user
            )
            detalle_nota.save()
            print(f"Detalle de nota creado para {detalle_nota.estudiante.nombre}")
            
    def seleccionar_estudiantes():
        # Seleccionar todos los estudiantes cuyo nombre comienza con 'Est'
        estudiantes = Estudiante.objects.filter(nombre__startswith='Est')
        print("Estudiantes cuyo nombre comienza con 'Est':")
        for estudiante in estudiantes:
            print(estudiante.nombre)

    def seleccionar_profesores():
        # Seleccionar todos los estudiantes cuyo nombre comienza con 'Est'
        profesores = Profesor.objects.filter(nombre__contains='or')
        print("Profesores cuyo nombre contiene 'or':")
        for profesor in profesores:
            print(profesor.nombre)
    # Llamar a la función interna para crear profesores (las otras funciones están definidas pero no se llaman)

    def buscar_notas_menor_que_nueve():
        # Seleccionar todas las notas donde nota2 es menor que 9.0
        notas = Nota.objects.filter(nota2__lt=9.0)
        print("Notas con nota2 menor que 9.0:")
        for nota in notas:
            print(f"Estudiante: {nota.estudiante.username}, Nota2: {nota.nota2}")
    # crear_periodos()
    # crear_asignaturas()
    crear_profesores()
    #crear_estudiantes()
    # crear_notas()
    # crear_detalles_notas()
    #seleccionar_estudiantes()
    seleccionar_profesores()
# Ejecutar la función para probar el ORM
probar_orm()
