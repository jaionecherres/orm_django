from django.contrib import admin
from .models import Periodo, Asignatura, Profesor, Estudiante, Nota, DetalleNota

@admin.register(Periodo)
class PeriodoAdmin(admin.ModelAdmin):
    list_display = ('periodo', 'user', 'created', 'updated', 'state')
    search_fields = ('periodo',)
    list_filter = ('state',)
    ordering = ('periodo',)

@admin.register(Asignatura)
class AsignaturaAdmin(admin.ModelAdmin):
    list_display = ('descripcion', 'user', 'created', 'updated', 'state')
    search_fields = ('descripcion',)
    list_filter = ('state',)
    ordering = ('descripcion',)

@admin.register(Profesor)
class ProfesorAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'cedula', 'user', 'created', 'updated', 'state')
    search_fields = ('nombre', 'cedula')
    list_filter = ('state',)
    ordering = ('nombre',)

@admin.register(Estudiante)
class EstudianteAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'cedula', 'user', 'created', 'updated', 'state')
    search_fields = ('nombre', 'cedula')
    list_filter = ('state',)
    ordering = ('nombre',)

@admin.register(Nota)
class NotaAdmin(admin.ModelAdmin):
    list_display = ('id', 'periodo', 'profesor', 'asignatura', 'user', 'created', 'updated', 'state')
    search_fields = ('id', 'profesor_nombre', 'asignatura_descripcion')
    list_filter = ('periodo', 'profesor', 'asignatura', 'state')
    ordering = ('id',)

@admin.register(DetalleNota)
class DetalleNotaAdmin(admin.ModelAdmin):
    list_display = ('nota', 'estudiante', 'nota1', 'nota2', 'recuperacion', 'observacion', 'user', 'created', 'updated', 'state')
    search_fields = ('estudiante_nombre', 'nota_id')
    list_filter = ('nota', 'estudiante', 'state')
    ordering = ('nota',)